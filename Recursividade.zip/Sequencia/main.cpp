#include <iostream>

using namespace std;

void seq(int a, int b)
{
    if(a <= b)
    {
        cout << a << " ";
        seq(a+1, b);
    }
}

void seqIt(int a, int b)
{
    for(int i = a; i <= b; i++)
        cout << i << " ";
    cout << endl;
}

int main()
{
    seq(0, 10);
    //cout << endl;
    //seqIt(10, 0);
    return 0;
}
