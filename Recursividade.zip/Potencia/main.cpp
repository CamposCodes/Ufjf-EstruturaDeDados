#include <iostream>

using namespace std;

float pot(float x, int n)
{
    if(n == 0)
        return 1.0;
    if(n < 0)
        return 1.0/pot(x, -n);
    return x * pot(x, n-1);
}

int main()
{
    float p = pot(2, -4);
    cout << p << endl;
    return 0;
}
