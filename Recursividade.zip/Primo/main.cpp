#include <iostream>

using namespace std;

bool auxPrimo(int n, int i)
{
    if(i == n)
        return true;
    if(n % i == 0)
        return false;
    return auxPrimo(n, i+1);
}
bool ehPrimo(int n)
{
    return auxPrimo(n, 2);
}

bool ehPrimoIt(int n)
{
    for(int i = 2; i < n; i++)
        if(n % i == 0)
            return false;
    return true;
}

int main()
{
    cout << ehPrimoIt(5) << endl;
    cout << ehPrimo(5) << endl;
    return 0;
}
