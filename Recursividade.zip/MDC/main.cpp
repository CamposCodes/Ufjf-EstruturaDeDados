#include <iostream>

using namespace std;

int mdc(int m, int n)
{
    if(m < n)
        return mdc(n, m);
    else if(m%n == 0) // caso base - conhecido
        return n;
    else // passo recursivo
        return mdc(n, m%n);
}


int main()
{
    cout << mdc(18, 3) << endl;
    cout << mdc(14, 4) << endl;
    cout << mdc(4, 14) << endl;
    cout << mdc(18, 7) << endl;
    cout << mdc(20, 6) << endl;
    cout << mdc(21, 6) << endl;
    return 0;
}
