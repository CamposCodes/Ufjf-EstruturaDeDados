#include <iostream>

using namespace std;

int fatorial(int n)
{
    int fat;
    if(n == 1)
        fat = 1;
    else
        fat = n * fatorial(n-1);
    return fat;
}

int main()
{
    int fat = fatorial(4);
    cout << fat << endl;
    return 0;
}
