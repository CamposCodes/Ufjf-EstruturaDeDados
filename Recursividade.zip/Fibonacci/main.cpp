#include <iostream>

using namespace std;

int fib(int n)
{
    if(n == 0 || n == 1)
        return n;
    return fib(n-1) + fib(n-2);
}

int fibIt(int n)
{
    if(n <= 0)
        return 0;
    int ant = 0;
    int atual = 1;
    int prox;
    for(int i = 2; i <= n; i++)
    {
        prox = atual + ant;
        ant = atual;
        atual = prox;
    }
    return atual;
}

int auxFib2(int atual, int anterior, int n)
{
    if(n == 0)
        return 0;
    if(n == 1)
        return atual;
    return auxFib2(atual + anterior, atual, n-1);
}

int fib2(int n)
{
    return auxFib2(1, 0, n);
}

int main()
{
    for(int i = 0; i < 10; i++)
        cout << fib(i) << " ";
    cout << endl;
    for(int i = 0; i < 10; i++)
        cout << fibIt(i) << " ";
    cout << endl;
    for(int i = 0; i < 10; i++)
        cout << fib2(i) << " ";
    cout << endl;
    return 0;
}
