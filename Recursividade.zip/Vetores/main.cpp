#include <iostream>

using namespace std;

int maior(int vet[], int n)
{
    if(n == 1)
        return vet[0];
    else
    {
        int mA = maior(vet, n-1);
        if(mA > vet[n-1])
            return mA;
        return vet[n-1];
    }
}

int maiorIt(int vet[], int n)
{
    int m = vet[0];
    for(int i = 1; i < n; i++)
        if(vet[i] > m)
            m = vet[i];
    return m;
}

int soma(int vet[], int n)
{
    if(n == 1)
        return vet[0];
    return soma(vet, n-1) + vet[n-1];
}


int main()
{
    int v[] = {1, 3, -4, 8, 5, 7};
    cout << "Maior: " << maiorIt(v, 6) << endl;
    cout << "Maior: " << maior(v, 6) << endl;
    cout << "Soma: " << soma(v, 6) << endl;
    return 0;
}
