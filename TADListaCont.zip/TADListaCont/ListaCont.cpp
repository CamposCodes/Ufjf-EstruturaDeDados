#include <iostream>
#include "ListaCont.h"

using namespace std;

ListaCont::ListaCont(int tam)
{
    max = tam;
    n = 0;
    vet = new int[max];
}

ListaCont::~ListaCont()
{
    delete [] vet;
}

void ListaCont::aumentaCapacidade()
{
    cout << "Aumentando a capacidade do vetor para " << max*2 << endl;
    int *temp = new int[max*2];
    for(int i = 0; i < n; i++)
        temp[i] = vet[i];
    delete [] vet;
    vet = temp;
    max *= 2;
}

int ListaCont::get(int k)
{
    if(k >= 0 && k < n)
        return vet[k];
    else
    {
        cout << "Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::set(int k, int val)
{
    if(k >= 0 && k < n)
        vet[k] = val;
    else
        cout << "Indice invalido!" << endl;
}

void ListaCont::insereFinal(int val)
{
    if(n == max)
    {
        cout << "Vetor cheio" << endl;
        aumentaCapacidade();
    }
    vet[n] = val;
    n++;
}

void ListaCont::insereInicio(int val)
{
    if(n == max)
    {
        cout << "Vetor cheio" << endl;
        aumentaCapacidade();
    }
    for(int i = n; i >= 1; i--)
        vet[i] = vet[i-1];
    //for(int i = n-1; i >= 0; i--)
    //    vet[i+1] = vet[i];
    vet[0] = val;
    n++;
}

void ListaCont::insereK(int k, int val)
{
    if(k >= 0 && k < n)
    {
        if(n == max)
        {
            cout << "Vetor cheio" << endl;
            aumentaCapacidade();
        }
        for(int i = n; i >= k+1; i--)
            vet[i] = vet[i-1];
        vet[k] = val;
        n++;
    }
    else
        cout << "Indice invalido" << endl;
}

void ListaCont::removeFinal()
{
    if(n > 0)
        n--;
    else
        cout << "Lista vazia" << endl;
}

void ListaCont::removeInicio()
{
    if(n > 0)
    {
        for(int i = 0; i < n; i++)
            vet[i] = vet[i+1];
        n--;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaCont::removeK(int k)
{
    if(n > 0)
    {
        if(k >= 0 && k < n)
        {
            for(int i = k; i < n; i++)
                vet[i] = vet[i+1];
            n--;
        }
        else
            cout << "Indice invalido" << endl;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaCont::imprime()
{
    cout << "Lista: ";
    for(int i = 0; i < n; i++)
        cout << vet[i] << " ";
    cout << endl;
}




