#include <iostream>
#include "ListaCont.h"

using namespace std;

int main()
{
    ListaCont l(10);
    l.imprime();

    l.removeFinal();
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereInicio(3);
    l.imprime();

    l.removeInicio();
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereK(2, 2);
    l.imprime();

    l.removeFinal();
    l.imprime();

    l.insereInicio(3);
    l.imprime();

    l.removeK(2);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereK(2,2);
    l.imprime();

    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereK(2,2);
    l.imprime();
    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    l.insereFinal(1);
    l.imprime();

    return 0;
}
