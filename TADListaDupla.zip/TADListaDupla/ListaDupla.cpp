#include <iostream>
#include "ListaDupla.h"

using namespace std;

ListaDupla::ListaDupla()
{
    primeiro = ultimo = NULL;
    n = 0;
}

ListaDupla::~ListaDupla()
{
    NoDuplo *p = ultimo;
    while(p != NULL)
    {
        NoDuplo *t = p->getAnt();
        delete p;
        p = t;
    }
}

void ListaDupla::insereInicio(int val)
{
    NoDuplo *p = new NoDuplo();
    p->setInfo(val);
    p->setProx(primeiro);
    p->setAnt(NULL);
    if(primeiro == NULL)
        ultimo = p;
    else
        primeiro->setAnt(p);
    primeiro = p;
    n++;
}

void ListaDupla::removeInicio()
{
    if(primeiro != NULL)
    {
        NoDuplo *p = primeiro;
        primeiro = p->getProx();
        delete p;
        if(primeiro == NULL)
            ultimo = NULL;
        else
            primeiro->setAnt(NULL);
        n--;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaDupla::insereFinal(int val)
{
    NoDuplo *p = new NoDuplo();
    p->setInfo(val);
    p->setAnt(ultimo);
    p->setProx(NULL);
    if(ultimo == NULL)
        primeiro = p;
    else
        ultimo->setProx(p);
    ultimo = p;
    n++;
}

void ListaDupla::removeFinal()
{
    if(ultimo != NULL)
    {
        NoDuplo *p = ultimo;
        ultimo = p->getAnt();
        delete p;
        if(ultimo == NULL)
            primeiro = NULL;
        else
            ultimo->setProx(NULL);
        n--;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaDupla::removeVal(int val)
{
    NoDuplo *p = primeiro;
    while(p != NULL)
    {
        if(p->getInfo() == val)
            break;
        p = p->getProx();
    }
    if(p == NULL)
        cout << "No " << val << " inexistente" << endl;
    else
    {
        NoDuplo *ant = p->getAnt();
        NoDuplo *prox = p->getProx();
        if(ant == NULL)
            primeiro = prox;
        else
            ant->setProx(prox);
        if(prox == NULL)
            ultimo = ant;
        else
            prox->setAnt(ant);
        delete p;
        n--;
    }
}

void ListaDupla::imprime()
{
    cout << "Lista: ";
    for(NoDuplo *p = primeiro; p != NULL; p = p->getProx())
        cout << p->getInfo() << " ";
    cout << endl;
    imprimeRec();
}

void ListaDupla::imprimeReverso()
{
    cout << "Lista Reversa: ";
    for(NoDuplo *p = ultimo; p != NULL; p = p->getAnt())
        cout << p->getInfo() << " ";
    cout << endl;
    imprimeReversoRec();
}

void ListaDupla::imprimeRec()
{
    cout << "Lista: ";
    auxImprimeRec(primeiro);
    cout << endl;
}
void ListaDupla::auxImprimeRec(NoDuplo *p)
{
    if(p != NULL)
    {
        cout << p->getInfo() << " ";
        auxImprimeRec(p->getProx());
    }
}

void ListaDupla::imprimeReversoRec()
{
    cout << "Lista Reversa: ";
    auxImprimeReversoRec(ultimo);
    cout << endl;
}
void ListaDupla::auxImprimeReversoRec(NoDuplo *p)
{
    if(p != NULL)
    {
        cout << p->getInfo() << " ";
        auxImprimeReversoRec(p->getAnt());
    }
}
