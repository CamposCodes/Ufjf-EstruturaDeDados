#include <iostream>
#include "ListaDupla.h"

using namespace std;

int main()
{
    ListaDupla l;

    l.insereInicio(1);
    l.insereInicio(2);
    l.insereInicio(3);
    l.insereInicio(4);
    l.insereInicio(5);
    l.imprime();
    l.imprimeReverso();

    l.insereFinal(5);
    l.insereFinal(6);
    l.insereFinal(7);
    l.insereFinal(8);
    l.insereFinal(9);
    l.imprime();
    l.imprimeReverso();

    l.removeVal(1);
    l.imprime();
    l.imprimeReverso();

    l.removeInicio();
    l.removeInicio();
    l.removeInicio();
    l.removeInicio();
    l.removeInicio();
    l.imprime();
    l.imprimeReverso();

    l.removeFinal();
    l.imprime();
    l.imprimeReverso();
    l.removeFinal();
    l.imprime();
    l.imprimeReverso();
    l.removeFinal();
    l.imprime();
    l.imprimeReverso();
    l.removeFinal();
    l.imprime();
    l.imprimeReverso();
    l.removeFinal();
    l.imprime();
    l.imprimeReverso();

    return 0;
}
