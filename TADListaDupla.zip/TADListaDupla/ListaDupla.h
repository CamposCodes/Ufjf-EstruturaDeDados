#ifndef LISTADUPLA_H_INCLUDED
#define LISTADUPLA_H_INCLUDED
#include "NoDuplo.h"

class ListaDupla
{
public:
    ListaDupla();
    ~ListaDupla();
    bool busca(int val);
    void insereInicio(int val);
    void removeInicio();
    void insereFinal(int val);
    void removeFinal();
    void removeVal(int val);
    void imprime();
    void imprimeRec();
    void imprimeReverso();
    void imprimeReversoRec();
private:
    NoDuplo *primeiro;
    int n;
    NoDuplo *ultimo;

    void auxImprimeRec(NoDuplo *p);
    void auxImprimeReversoRec(NoDuplo *p);
};

#endif // LISTADUPLA_H_INCLUDED
