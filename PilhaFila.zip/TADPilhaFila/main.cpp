#include <iostream>
#include "PilhaEncad.h"
#include "FilaEncad.h"

using namespace std;

void inverte(FilaEncad *f)
{
    PilhaEncad p;
    while(!f->vazia())
        p.empilha(f->desenfileira());
    while(!p.vazia())
        f->enfileira(p.desempilha());
}

void montaFilas(PilhaEncad *p, FilaEncad *f1, FilaEncad *f2)
{
    while(!f1->vazia())
        f1->desenfileira();
    while(!f2->vazia())
        f2->desenfileira();
    while(!p->vazia())
    {
        if(p->getTopo() >= 0)
            f1->enfileira(p->desempilha());
        else
            f2->enfileira(p->desempilha());
    }
}

int main()
{
    PilhaEncad p;
    FilaEncad f;

    p.empilha(1);
    p.empilha(2);
    p.empilha(3);
    p.imprime();

    f.enfileira(1);
    f.enfileira(2);
    f.enfileira(3);
    f.imprime();

    inverte(&f);
    f.imprime();

    p.empilha(0);
    p.empilha(-1);
    p.empilha(-2);
    p.imprime();

    FilaEncad f1, f2;

    montaFilas(&p, &f1, &f2);

    p.imprime();
    f1.imprime();
    f2.imprime();

    return 0;
}
