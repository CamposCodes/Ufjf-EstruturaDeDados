#include <iostream>
#include "FilaCirc.h"

using namespace std;

FilaCirc::FilaCirc(int tam)
{
    max = tam;
    inicio = fim = n = 0;
    vet = new int[max];
}

FilaCirc::~FilaCirc()
{
    delete [] vet;
}

int FilaCirc::inc(int ind)
{
    return (ind+1) % max;
}

int FilaCirc::getInicio()
{
    if(!vazia())
        return vet[inicio];
    else
    {
        cout << "Fila vazia" << endl;
        exit(1);
    }
}

void FilaCirc::enfileira(int val)
{
    if(n == max)
        cout << "Vetor cheio" << endl;
    else
    {
        vet[fim] = val;
        fim = inc(fim);
        n++;
    }
}

int FilaCirc::desenfileira()
{
    if(!vazia())
    {
        int val = vet[inicio];
        inicio = inc(inicio);
        n--;
        return val;
    }
    cout << "Lista vazia" << endl;
    exit(1);
}

bool FilaCirc::vazia()
{
    return n == 0;
}

