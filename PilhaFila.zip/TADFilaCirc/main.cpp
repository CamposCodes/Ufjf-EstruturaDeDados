#include <iostream>
#include "FilaCirc.h"

using namespace std;

int main()
{
    FilaCirc f(10);

    f.enfileira(1);
    f.enfileira(2);
    f.enfileira(3);
    f.enfileira(4);
    f.enfileira(5);
    f.enfileira(6);

    while(!f.vazia())
        cout << f.desenfileira() << " ";
    cout << endl;

    f.enfileira(1);
    f.enfileira(2);
    f.enfileira(3);
    f.enfileira(4);
    f.enfileira(5);
    f.enfileira(6);

    //while(!f.vazia())
    //    cout << f.desenfileira() << " ";
    //cout << endl;

    f.enfileira(1);
    f.enfileira(2);
    f.enfileira(3);
    f.enfileira(4);
    f.enfileira(5);
    f.enfileira(6);

    while(!f.vazia())
        cout << f.desenfileira() << " ";
    cout << endl;

    return 0;
}
