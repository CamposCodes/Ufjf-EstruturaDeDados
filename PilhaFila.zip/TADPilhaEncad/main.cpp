#include <iostream>
#include "PilhaEncad.h"

using namespace std;

bool ehPalindromo(PilhaEncad *p)
{
    PilhaEncad p1, p2, aux;
    int val;
    while(!p->vazia())
    {
        val = p->getTopo();
        p1.empilha(val);
        aux.empilha(val);
        p->desempilha();
    }
    while(!aux.vazia())
    {
        val = aux.getTopo();
        p->empilha(val);
        p2.empilha(val);
        aux.desempilha();
    }
    while(!p1.vazia())
        if(p1.desempilha() != p2.desempilha())
            return false;
    return true;
}

void concatena(PilhaEncad *p1, PilhaEncad *p2)
{
    PilhaEncad aux;
    while(!p2->vazia())
        aux.empilha(p2->desempilha());
    while(!aux.vazia())
        p1->empilha(aux.desempilha());
}

int main()
{
    PilhaEncad p1, p2;

    p1.empilha(1);
    p1.empilha(2);
    p1.empilha(3);
    p1.empilha(4);
    p1.imprime();

    p2.empilha(4);
    p2.empilha(3);
    p2.empilha(2);
    p2.empilha(1);
    p2.imprime();

    concatena(&p1, &p2);
    p1.imprime();
    p2.imprime();

    cout << ehPalindromo(&p1) << endl;
    cout << ehPalindromo(&p2) << endl;

    return 0;
}
