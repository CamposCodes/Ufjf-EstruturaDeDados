#include <iostream>
#include "PilhaEncad.h"

using namespace std;

PilhaEncad::PilhaEncad()
{
    topo = NULL;
}

PilhaEncad::~PilhaEncad()
{
    No *p = topo;
    while(p != NULL)
    {
        No *t = p->getProx();
        delete p;
        p = t;
    }
}

int PilhaEncad::getTopo()
{
    if(topo != NULL)
        return topo->getInfo();
    cout << "Pilha vazia" << endl;
    exit(1);
}

void PilhaEncad::empilha(int val)
{
    No *p = new No(); // cria No apontado por p
    p->setInfo(val); // preenche informacao
    p->setProx(topo); // preenche proximo
    topo = p; // no apontado por p passa a ser o primeiro da lista
}

int PilhaEncad::desempilha()
{
    if(topo != NULL)
    {
        No *p = topo;
        topo = p->getProx();
        int val = p->getInfo();
        delete p;
        return val;
    }
    cout << "Pilha vazia" << endl;
    exit(1);
}

bool PilhaEncad::vazia()
{
    return topo == NULL;
}

void PilhaEncad::imprime() // operação não convencional
{
    cout << "Pilha:" << endl;
    for(No *p = topo; p != NULL; p = p->getProx())
        cout << p->getInfo() << endl;
    cout << endl;
}
