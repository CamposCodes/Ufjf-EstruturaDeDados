#include <iostream>
#include "PilhaCont.h"

using namespace std;

int main()
{
    PilhaCont p(10);

    p.empilha(1);
    p.empilha(2);
    p.empilha(3);
    p.empilha(4);

    p.imprime();

    PilhaCont p2(10);

    p2.empilha(p.desempilha());
    p2.empilha(p.desempilha());

    p.imprime();
    p2.imprime();

    p.empilha(5);
    p.empilha(p2.desempilha());
    p.empilha(p2.desempilha());

    p.imprime();
    p2.imprime();

    //while(!p.vazia())
    //    cout << p.desempilha() << endl;

    return 0;
}
