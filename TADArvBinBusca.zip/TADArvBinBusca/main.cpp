#include <iostream>
#include "ArvBinBusca.h"

using namespace std;

int main()
{
    ArvBinBusca arv;

    arv.insereIt(20);
    //arv.imprime();
    //arv.removeMinimoIt();
    //arv.imprime();
    arv.insere(10);
    arv.insere(30);
    arv.insere(5);
    arv.insere(15);
    arv.insere(18);
    arv.insere(40);
    arv.insere(35);
    arv.insere(48);
    arv.insere(44);
    arv.imprime();
    arv.imprimeIntervalo(10, 35);

    cout << "Busca 44: " << arv.busca(44) << endl;
    cout << "Busca 44: " << arv.buscaIt(44) << endl;
    cout << "Busca 22: " << arv.busca(22) << endl;
    cout << "Busca 22: " << arv.buscaIt(22) << endl;

    cout << "Minimo: " << arv.minimo() << endl;
    cout << "Minimo: " << arv.minimoIt() << endl;

    arv.remove(44);
    arv.imprime();

    arv.remove(20);
    arv.imprime();

    arv.insereIt(7);
    arv.imprime();

    arv.removeMinimoIt();
    arv.imprime();

    return 0;
}
