#include <iostream>
#include "ArvBinBusca.h"

using namespace std;

ArvBinBusca::ArvBinBusca()
{
    raiz = NULL;
}

ArvBinBusca::~ArvBinBusca()
{
    libera(raiz);
}

void ArvBinBusca::libera(NoArv *p)
{
    if(p != NULL)
    {
        libera(p->getEsq());
        libera(p->getDir());
        delete p;
    }
}

int ArvBinBusca::getRaiz()
{
    if(raiz != NULL) //ou if(!vazia())
        return raiz->getInfo();
    else
    {
        cout << "Árvora vazia!" << endl;
        exit(1);
    }
}

bool ArvBinBusca::vazia()
{
    return raiz == NULL;
}

bool ArvBinBusca::busca(int val)
{
    return auxBusca(raiz, val);
}
bool ArvBinBusca::auxBusca(NoArv *p, int val)
{
    if(p == NULL)
        return false;
    if(p->getInfo() == val)
        return true;
    if(val < p->getInfo())
        return auxBusca(p->getEsq(), val);
    return auxBusca(p->getDir(), val); // val > p->getInfo()
}

bool ArvBinBusca::buscaIt(int val)
{
    NoArv *p = raiz;
    while(p != NULL)
    {
        if(p->getInfo() == val)
            return true;
        else if(val < p->getInfo())
            p = p->getEsq();
        else
            p = p->getDir();
    }
    return false;
}

void ArvBinBusca::insere(int val)
{
    raiz = auxInsere(raiz, val);
}

NoArv* ArvBinBusca::auxInsere(NoArv *p, int val)
{
    if(p == NULL)
    {
        p = new NoArv();
        p->setInfo(val);
        p->setEsq(NULL);
        p->setDir(NULL);
    }
    else if(val < p->getInfo())
        p->setEsq(auxInsere(p->getEsq(), val));
    else // val >= p->getInfo()
        p->setDir(auxInsere(p->getDir(), val));
    return p;
}

void ArvBinBusca::insereIt(int val)
{
    NoArv *p = raiz;
    NoArv *pai = NULL;
    while(p != NULL)
    {
        pai = p;
        if(val < p->getInfo())
            p = p->getEsq();
        else // val >= p->getInfo()
            p = p->getDir();
    }
    p = new NoArv();
    p->setInfo(val);
    p->setEsq(NULL);
    p->setDir(NULL);
    if(pai == NULL)
        raiz = p;
    else if(val < pai->getInfo())
        pai->setEsq(p);
    else
        pai->setDir(p);
}


void ArvBinBusca::imprime()
{
    auxImprime(raiz, 0);
    cout << endl;
}
void ArvBinBusca::auxImprime(NoArv *p, int nivel)
{
    if(p != NULL)
    {
        auxImprime(p->getEsq(), nivel+1);
        cout << "(" << nivel << ")";
        for(int i = 0; i < nivel; i++)
            cout << "--";
        cout << p->getInfo() << endl;
        auxImprime(p->getDir(), nivel+1);
    }
}

void ArvBinBusca::imprimeIntervalo(int a, int b)
{
    cout << "Nos no intervalo [" << a << ", " << b << "]: ";
    auxImprimeIntervalo(raiz, a, b);
    cout << endl;
}
void ArvBinBusca::auxImprimeIntervalo(NoArv *p, int a, int b)
{
    if(p != NULL)
    {
        if(p->getInfo() > a)
            auxImprimeIntervalo(p->getEsq(), a, b);
        if(p->getInfo() >= a && p->getInfo() <= b)
            cout << p->getInfo() << " ";
        if(p->getInfo() <= b)
            auxImprimeIntervalo(p->getDir(), a, b);
    }
}

int ArvBinBusca::minimo()
{
    if(raiz == NULL)
        exit(1);
    return auxMinimo(raiz);
}
int ArvBinBusca::auxMinimo(NoArv *p)
{
    if(p->getEsq() != NULL)
        return auxMinimo(p->getEsq());
    return p->getInfo();
}

int ArvBinBusca::minimoIt()
{
    if(raiz == NULL)
        exit(1);
    NoArv *p = raiz;
    while(p->getEsq() != NULL)
        p = p->getEsq();
    return p->getInfo();
}

void ArvBinBusca::remove(int val)
{
    raiz = auxRemove(raiz, val);
}

NoArv* ArvBinBusca::auxRemove(NoArv *p, int val)
{
    if(p == NULL)
        cout << "No inexistente" << endl;
    else if(val < p->getInfo())
        p->setEsq(auxRemove(p->getEsq(), val));
    else if(val > p->getInfo())
        p->setDir(auxRemove(p->getDir(), val));
    else // val == p->getInfo()
    {
        if(p->getEsq() == NULL && p->getDir() == NULL)
        {
            delete p;
            p = NULL;
        }
        else if(p->getEsq() == NULL || p->getDir() == NULL)
        {
            NoArv *aux;
            if(p->getEsq() != NULL)
                aux = p->getEsq();
            else
                aux = p->getDir();
            delete p;
            p = aux;
        }
        else
        {
            NoArv *aux = p->getEsq();
            while(aux->getDir() != NULL)
                aux = aux->getDir();
            p->setInfo(aux->getInfo());
            aux->setInfo(val);
            p->setEsq(auxRemove(p->getEsq(), val));
        }
    }
    return p;
}

void ArvBinBusca::removeMinimoIt()
{
    if(raiz == NULL)
        cout << "Arvore vazia" << endl;
    else
    {
        NoArv *p = raiz;
        NoArv *pai = NULL;
        while(p->getEsq() != NULL)
        {
            pai = p;
            p = p->getEsq();
        }
        NoArv *aux = NULL;
        if(p->getDir() != NULL)
            aux = p->getDir();
        delete p;
        if(pai == NULL)
            raiz = aux;
        else
            pai->setEsq(aux);
    }
}
