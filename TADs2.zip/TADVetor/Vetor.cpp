#include <iostream>
#include "Vetor.h"

using namespace std;

Vetor::Vetor(int tam)
{
    n = tam;
    vet = new float[n];
}

Vetor::~Vetor()
{
    delete [] vet;
}

float Vetor::get(int indice)
{
    if(verifica(indice))
        return vet[indice];
    cout << "indice invalido" << endl;
    exit(1);
}

void Vetor::set(int indice, float valor)
{
    if(verifica(indice))
        vet[indice] = valor;
    else
        cout << "indice invalido" << endl;
}

bool Vetor::verifica(int indice)
{
    return indice >= 0 && indice < n;
}

int Vetor::tamanho()
{
    return n;
}
