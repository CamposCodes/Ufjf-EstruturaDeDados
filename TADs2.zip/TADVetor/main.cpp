#include <iostream>
#include "Vetor.h"

using namespace std;

int main()
{
    Vetor v(10);
    v.set(1, 1);
    for(int i = 0; i < v.tamanho(); i++)
        cout << v.get(i) << " ";
    cout << endl;



    return 0;
}
