#include <iostream>
#include "Ponto.h"

using namespace std;

int main()
{
    Ponto p1(1, 2);
    Ponto p2(3, 4);

    Ponto *p3;

    p3 = new Ponto(4, 5);

    cout << p3->getX() << endl;

    cout << "Distancia: " << p1.distancia(&p2) << endl;
    cout << "Distancia: " << p2.distancia(&p1) << endl;

    delete p3;

    return 0;
}
