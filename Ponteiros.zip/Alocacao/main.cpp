#include <iostream>

using namespace std;

float* somaVetores(float u[], float v[])
{
    float *r = new float[3];
    r[0] = u[0] + v[0];
    r[1] = u[1] + v[1];
    r[2] = u[2] + v[2];
    return r;
}

int main()
{
    float a[] = {1, 2, 3};
    float b[] = {1, 2, 3};
    float *c = somaVetores(a, b);
    cout << c[0] << " " << c[1] << " " << c[2] << endl;
    delete [] c;

    int *v = new int[7];
    int *v2;
    for(int i = 0; i < 7; i++)
        v[i] = i+1;

    v2 = new int[8];
    for(int i = 0; i < 7; i++)
        v2[i] = v[i];
    v2[7] = 10;
    delete [] v;
    v = v2;
    v2 = NULL;

    delete [] v;

    return 0;
}
