#include <iostream>

using namespace std;

void func( )
{
    int mat[ ] = {1, 10, 100};
    int *p=mat;
    for(int j=0; j<3; j++)
        cout << (*p)++ << endl;
}

void troca(int a, int b)
{
    int aux = b;
    b = a;
    a = aux;
}

int main()
{
    /*
    int biscoitos = 6;
    double peso = 4.5;
    double peso2 = 14.5;
    cout << "valor de biscoitos: " << biscoitos;
    cout << " endereco de biscoitos: ";
    cout << &biscoitos << endl;
    cout << "valor de peso: " << peso;
    cout << " endereco de peso: " << &peso << endl;
    cout << "valor de peso2: " << peso2;
    cout << " endereco de peso2: " << &peso2 << endl;
    */
    ///
    /*
    int updates = 6, a = 9, *p_updates;

    p_updates = &updates;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    updates++;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    *p_updates = 15;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    p_updates = &a;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    *p_updates = 25;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    p_updates = p_updates + 1;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;

    p_updates = p_updates + 1;
    cout << "updates = " << updates << endl;
    cout << "&updates = " << &updates << endl;
    cout << "p_updates = " << p_updates << endl;
    cout << "&p_updates = " << &p_updates << endl;
    cout << "*p_updates = " << *p_updates << endl;
    cout << "a = " << a << endl;
    cout << "&a = " << &a << endl << endl;
    */
    ///
    /*
    int vet[3] = {10, 20, 30};

    cout << "enderecos" << endl;
    cout << vet << endl;
    cout << vet+1 << endl;
    cout << vet+2 << endl;

    cout << "valores" << endl;
    cout << vet[0] << endl;
    cout << vet[1] << endl;
    cout << vet[2] << endl;

    vet[0] = 1;
    vet[1] = 2;
    vet[2] = 3;

    cout << "valores" << endl;
    cout << *(vet+0) << endl;
    cout << *(vet+1) << endl;
    cout << *(vet+2) << endl;

    *(vet+0) = 10;
    *(vet+1) = 20;
    *(vet+2) = 30;

    cout << "valores" << endl;
    cout << *(vet+0) << endl;
    cout << *(vet+1) << endl;
    cout << *(vet+2) << endl;
    */
    ///
    /*
    int * ptr = NULL;
    int *ptr2; // ptr2 nao foi inicializado
    ptr2 = 0; // ptr2 agora aponta pra null
    cout << ptr << endl;
    */
    ///
    /*
    int x=2, y=30;
    troca(x, y);
    cout << "x = " << x << " , ";
    cout << "y = " << y << endl;
    return 0;
    */
    ///

    int i, j, *p, *q;

    p=&i;

    func();


}
