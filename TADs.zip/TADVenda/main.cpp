#include <iostream>
#include "Venda.h"

using namespace std;

int main()
{
    Venda v(10);
    cout << "Total: " << v.calculaTotal() << endl;
    cout << "Item mais caro: " << v.itemMaisCaro() << endl;
    return 0;
}
