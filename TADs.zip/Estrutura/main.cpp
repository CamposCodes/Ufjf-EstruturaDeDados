#include <iostream>

using namespace std;


typedef struct aluno
{
    int mat;
    float notas[3];
} aluno;

void alteraMatricula(aluno *a)
{
    cout << "Digite uma matricula: ";
    cin >> (*a).mat;
    while((*a).mat <= 0)
    {
        cout << "Matricula invalida. Digite uma matricula: ";
        cin >> (*a).mat;
    }
}

void leAluno(aluno *a)
{
    cout << "Digite uma matricula: ";
    cin >> (*a).mat;
    while((*a).mat <= 0)
    {
        cout << "Matricula invalida. Digite uma matricula: ";
        cin >> (*a).mat;
    }
    for(int i = 0; i < 3; i++)
    {
        cout << "Digite a nota " << i+1 << ": ";
        cin >> (*a).notas[i];
        while((*a).notas[i] < 0 || (*a).notas[i] > 100)
        {
            cout << "Nota invalida. Digite uma nota entre 0 e 100: ";
            cin >> (*a).notas[i];
        }
    }
}

void imprimeAluno(struct aluno *a)
{
    cout << "Matricula: " << (*a).mat << endl;
    for(int i = 0; i < 3; i++)
        cout << "Nota " << i+1 << ": " << (*a).notas[i] << endl;
}

int main()
{
    struct aluno a;
    leAluno(&a);
    imprimeAluno(&a);
    alteraMatricula(&a);
    imprimeAluno(&a);
    return 0;
}
