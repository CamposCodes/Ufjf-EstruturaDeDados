#include <math.h>
#include "Poligono.h"

Poligono::Poligono(int n, float l)
{
    setNumLados(n);
    setTamLado(l);
}

Poligono::~Poligono()
{

}

void Poligono::setNumLados(int n)
{
    if (n >= 3) numLados = n;
}

void Poligono::setTamLado(int l)
{
    if(l > 0) tamLado = l;
}

float Poligono::area()
{
    return numLados*pow(tamLado,2) / (4*tan(3.141592/numLados));
}

float Poligono::perimetro()
{
    return numLados*tamLado;
}

float Poligono::angInterno()
{
    return 180*(numLados - 2)/numLados;
}
