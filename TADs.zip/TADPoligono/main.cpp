#include <iostream>
#include "Poligono.h"

using namespace std;

int main()
{
    Poligono p(4, 10);

    cout << p.area() << endl;
    cout << p.perimetro() << endl;
    cout << p.angInterno() << endl;

    return 0;
}
