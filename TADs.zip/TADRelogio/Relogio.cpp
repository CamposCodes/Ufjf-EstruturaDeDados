#include "Relogio.h"

void Relogio::acertar(int h, int m, int s)
{
    horas = 0;
    if(h > 0 && h <= 12)
        horas = h;

    minutos = 0;
    if(m > 0 && m <= 59)
        minutos = m;

    segundos = 0;
    if(s > 0 && s <= 59)
        segundos = s;
}

int Relogio::getHora()
{
    return horas;
}

int Relogio::getMinuto()
{
    return minutos;
}

int Relogio::getSegundo()
{
    return segundos;
}

void Relogio::tique()
{
    segundos++;
    if(segundos == 60)
    {
        minutos++;
        segundos = 0;
    }
    if(minutos == 60)
    {
        horas++;
        minutos = 0;
    }
    if(horas > 12)
        horas = 0;
}
