#include <iostream>
#include "Relogio.h"

using namespace std;

int main()
{
    Relogio r;
    cout << r.getHora() << ":" << r.getMinuto() << ":" << r.getSegundo() << endl;

    r.acertar(10, 59, 58);

    cout << r.getHora() << ":" << r.getMinuto() << ":" << r.getSegundo() << endl;

    r.tique();
    cout << r.getHora() << ":" << r.getMinuto() << ":" << r.getSegundo() << endl;

    r.tique();
    cout << r.getHora() << ":" << r.getMinuto() << ":" << r.getSegundo() << endl;
    return 0;
}
