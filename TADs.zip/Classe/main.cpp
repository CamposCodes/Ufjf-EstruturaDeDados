#include <iostream>

using namespace std;

class aluno
{
  private:
    int matricula;
    float notas[3];
  public:
    aluno(int m);
    ~aluno();
    void setMatricula(int m);
    int getMatricula();
    void leAluno();
    void imprimeAluno();
};

aluno::aluno(int m)
{
    cout << "Construtor" << endl;
    setMatricula(m);
}

aluno::~aluno()
{
    cout << "Destrutor" << endl;
}

void aluno::setMatricula(int m)
{
    if(m <= 0)
        cout << "Matricula invalida" << endl;
    else
        matricula = m;
}

int aluno::getMatricula()
{
    return matricula;
}

void aluno::leAluno()
{
    cout << "Digite uma matricula: ";
    cin >> matricula;
    while(matricula <= 0)
    {
        cout << "Matricula invalida. Digite uma matricula: ";
        cin >> matricula;
    }
    for(int i = 0; i < 3; i++)
    {
        cout << "Digite a nota " << i+1 << ": ";
        cin >> notas[i];
        while(notas[i] < 0 || notas[i] > 100)
        {
            cout << "Nota invalida. Digite uma nota entre 0 e 100: ";
            cin >> notas[i];
        }
    }
}

void aluno::imprimeAluno()
{
    cout << "Matricula: " << matricula << endl;
    for(int i = 0; i < 3; i++)
        cout << "Nota " << i+1 << ": " << notas[i] << endl;
}

int main()
{
    aluno a(-10);
    //a.leAluno();
    a.imprimeAluno();
    a.setMatricula(10);
    a.imprimeAluno();

    cout << a.getMatricula() << endl;

    return 0;
}
