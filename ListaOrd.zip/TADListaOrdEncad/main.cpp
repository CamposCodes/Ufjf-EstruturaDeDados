#include <iostream>
#include "ListaOrdEncad.h"

using namespace std;

int main()
{
    ListaOrdEncad l;

    l.insere(5);
    l.imprime();
    l.insere(1);
    l.imprime();
    l.insere(4);
    l.imprime();
    l.insere(6);
    l.imprime();
    l.insere(8);
    l.imprime();
    l.insere(2);
    l.imprime();
    l.insere(3);
    l.imprime();
    l.insere(7);
    l.imprime();

    l.remove(7);
    l.imprime();
    l.remove(5);
    l.imprime();
    l.remove(10);
    l.imprime();
    l.remove(4);
    l.imprime();
    l.remove(2);
    l.imprime();

    return 0;
}
