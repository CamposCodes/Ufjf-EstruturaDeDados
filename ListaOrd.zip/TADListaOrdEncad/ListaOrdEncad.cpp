#include <iostream>
#include "ListaOrdEncad.h"

using namespace std;

ListaOrdEncad::ListaOrdEncad()
{
    primeiro = NULL;
}

ListaOrdEncad::~ListaOrdEncad()
{
    No *p = primeiro;
    while(p != NULL)
    {
        No *t = p->getProx();
        delete p;
        p = t;
    }
}

void ListaOrdEncad::insere(int val)
{
    No *p = primeiro;
    No *ant = NULL;
    while(p != NULL)
    {
        if(p->getInfo() > val)
            break;
        ant = p;
        p = p->getProx();
    }
    No *novo = new No();
    novo->setInfo(val);
    novo->setProx(p);
    if(ant == NULL)
        primeiro = novo;
    else
        ant->setProx(novo);
}

void ListaOrdEncad::remove(int val)
{
    if(primeiro != NULL)
    {
        No *p = primeiro;
        No *ant = NULL;
        while(p != NULL)
        {
            if(p->getInfo() == val)
                break;
            ant = p;
            p = p->getProx();
        }
        if(p == NULL)
            cout << "Valor inexistente" << endl;
        else
        {
            if(ant == NULL)
                primeiro = p->getProx();
            else
                ant->setProx(p->getProx());
            delete p;
        }
    }
    else
        cout << "Lista vazia" << endl;
}

bool ListaOrdEncad::busca(int val)
{
    for(No *p = primeiro; p != NULL; p = p->getProx())
    {
        if(p->getInfo() == val)
            return true;
        if(p->getInfo() > val) // vantagem da ordenação
            return false;
    }
    return false;
}

void ListaOrdEncad::imprime()
{
    cout << "Lista: ";
    for(No *p = primeiro; p != NULL; p = p->getProx())
        cout << p->getInfo() << " ";
    cout << endl;
}




