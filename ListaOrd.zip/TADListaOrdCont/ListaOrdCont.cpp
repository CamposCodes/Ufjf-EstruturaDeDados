#include <iostream>
#include "ListaOrdCont.h"

using namespace std;

ListaOrdCont::ListaOrdCont(int tam)
{
    max = tam;
    n = 0;
    vet = new int[tam];
}

ListaOrdCont::~ListaOrdCont()
{
    delete [] vet;
}

int ListaOrdCont::get(int k)
{
    if(k >= 0 && k < n)
        return vet[k];
    cout << "Indice invalido" << endl;
    exit(1);
}

void ListaOrdCont::insere(int val)
{
    if(n == max)
    {
        cout << "Vetor Cheio!" << endl;
        exit(3);
    }
    int i;
    for(i = n; i > 0 && vet[i-1] >= val; i--)
        vet[i] = vet[i-1];
    vet[i] = val;
    n++;
}

void ListaOrdCont::remove(int val)
{
    int k = buscaBinaria(val);
    if(k != -1)
    {
        for(int i = k; i < n-1; i++) // copia da dir. para esq.
            vet[i] = vet[i+1];
        n--;
    }
    else
        cout << "Valor inexistente" << endl;
}

void ListaOrdCont::imprime()
{
    cout << "Lista: ";
    for(int i = 0; i < n; i++)
        cout << vet[i] << " ";
    cout << endl;
}

bool ListaOrdCont::busca(int val)
{
    int k = buscaBinaria(val);
    // retorna true, se k eh um indice valido
    // returna false, caso contrario
    return k >= 0 && k < n;
}

int ListaOrdCont::buscaBinaria(int val)
{
    int esq = 0;
    int dir = n-1;
    while(esq <= dir)
    {
        int meio = (esq + dir) / 2;
        if(val > vet[meio]) // se existir, val esta na segunda metade
            esq = meio + 1;
        else if (val < vet[meio]) // se existir, val esta na primeira metade
            dir = meio - 1;
        else
            return meio; // val na posicao meio
    }
    return -1; // val nao encontrado
}
