#include <iostream>
#include "ListaOrdCont.h"

using namespace std;

int main()
{
    ListaOrdCont l(10);

    l.insere(8);
    l.imprime();
    l.insere(2);
    l.imprime();
    l.insere(6);
    l.imprime();
    l.insere(3);
    l.imprime();
    l.insere(4);
    l.imprime();
    l.insere(1);
    l.imprime();
    l.insere(5);
    l.imprime();
    l.insere(7);
    l.imprime();
    l.insere(9);
    l.imprime();

    l.remove(6);
    l.imprime();
    l.remove(6);
    l.imprime();
    l.remove(4);
    l.imprime();
    l.remove(3);
    l.imprime();
    l.remove(1);
    l.imprime();
    l.remove(2);
    l.imprime();
    l.remove(5);
    l.imprime();

    return 0;
}
