#include <iostream>
#include "MatrizTriDiag.h"

using namespace std;

MatrizTriDiag::MatrizTriDiag(int ordem)
{
    dim = ordem;
    diagPri = new float[dim];
    diagSup = new float[dim-1];
    diagInf = new float[dim-1];
}

MatrizTriDiag::~MatrizTriDiag()
{
    delete [] diagPri;
    delete [] diagSup;
    delete [] diagInf;
}

float MatrizTriDiag::get(int i, int j)
{
    if(verifica(i, j))
    {
        if(i == j) // diagonal principal
            return diagPri[i];
        else if(i-j == -1) // diagonal superior
            return diagSup[i];
        else if(i-j == 1) // diagonal inferior
            return diagInf[j];
        else
            return 0.0;
    }
    cout << "indice invalido" << endl;
    exit(1);
}

void MatrizTriDiag::set(int i, int j, float val)
{
    if(verifica(i, j))
    {
        if(i == j) // diagonal principal
            diagPri[i] = val;
        else if(i-j == -1) // diagonal superior
            diagSup[i] = val;
        else if(i-j == 1) // diagonal inferior
            diagInf[j] = val;
        else if(val != 0)
            cout << "valor invalido" << endl;
    }
    else
        cout << "indice invalido" << endl;
}

bool MatrizTriDiag::verifica(int i, int j)
{
    return i >= 0 && i < dim && j >= 0 && j < dim;
}
