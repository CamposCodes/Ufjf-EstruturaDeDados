#ifndef MATRIZTRIDIAG_H_INCLUDED
#define MATRIZTRIDIAG_H_INCLUDED

class MatrizTriDiag
{
public:
    MatrizTriDiag(int ordem);
    ~MatrizTriDiag();
    float get(int i, int j);
    void set(int i, int j, float val);
private:
    int dim; // numero de linhas e colunas
    float *diagPri, *diagSup, *diagInf; //3 vetores
    bool verifica(int i, int j);
};

#endif // MATRIZTRIDIAG_H_INCLUDED
