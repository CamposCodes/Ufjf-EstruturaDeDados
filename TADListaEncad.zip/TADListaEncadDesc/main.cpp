#include <iostream>
#include "ListaEncad.h"

using namespace std;

int main()
{
    ListaEncad l, *l2;

    l.insereInicio(1);
    l.imprime();
    l.insereInicio(2);
    l.imprime();
    l.insereInicio(3);
    l.imprime();
    l.insereInicio(4);
    l.imprime();
    l.insereApos(2, 10);
    l.imprime();
    l.insereApos(4, 20);
    l.imprime();
    l.insereInicio(40);
    l.imprime();
    l.removeInicio();
    l.imprime();
    l.insereFinal(40);
    l.imprime();
    l.removeFinal();
    l.imprime();

    l2 = l.partir(4);

    l.insereFinal(1);

    l.imprime();
    l2->imprime();

    delete l2;


    return 0;
};
