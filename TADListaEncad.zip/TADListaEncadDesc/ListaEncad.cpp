#include <iostream>
#include <cstdlib>
#include "ListaEncad.h"

using namespace std;

ListaEncad::ListaEncad()
{
    n = 0;
    primeiro = NULL;
    ultimo = NULL;
    m = 0;
}

ListaEncad::~ListaEncad()
{
    No *p = primeiro;
    while(p != NULL)
    {
        No *t = p->getProx();
        delete p;
        p = t;
    }
}

void ListaEncad::insereInicio(int val)
{
    No *p = new No();
    p->setInfo(val);
    p->setProx(primeiro);
    if(primeiro == NULL)
    {
        ultimo = p;
        m = val;
    }
    primeiro = p;
    n++;
    if(val > m)
        m = val;
}

void ListaEncad::removeInicio()
{
    if(primeiro != NULL)
    {
        No *p = primeiro;
        primeiro = p->getProx();
        int val = p->getInfo();
        delete p;
        if(primeiro == NULL)
            ultimo = NULL;
        n--;
        if(val == m)
            m = auxMaior();
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaEncad::insereFinal(int val)
{
    No *p = new No(); // alocação
    p->setInfo(val);  // ajuste novo info
    p->setProx(NULL); // ajuste novo prox
    if(primeiro == NULL) // lista vazia
    {
        primeiro = p;
        m = val;
    }
    else
        ultimo->setProx(p); //ajuste ultimo prox
    ultimo = p;
    n++;
    if(val > m)
        m = val;
}

void ListaEncad::removeFinal()
{
    int val;
    if(primeiro != NULL)
    {
        if(primeiro == ultimo) // só tem um n
        {
            val = ultimo->getInfo();
            delete ultimo;
            primeiro = ultimo = NULL;
        }
        else
        {
            No *penultimo = primeiro;
            while(penultimo->getProx() != ultimo)
                penultimo = penultimo->getProx();
            penultimo->setProx(NULL);
            val = ultimo->getInfo();
            delete ultimo;
            ultimo = penultimo;
        }
        n--;
        if(val == m)
            m = auxMaior();
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaEncad::insereK(int k, int val)
{
    if(k == 0)
        insereInicio(val);
    else
    {
        int i = 0;
        No *p = primeiro;
        No *ant = NULL;
        while(p != NULL && i < k)
        {
            ant = p;
            p = p->getProx();
            i++;
        }
        if(p == NULL)
            cout << "Indice invalido" << endl;
        else
        {
            No *novo = new No();
            novo->setInfo(val);
            novo->setProx(p);
            ant->setProx(novo);
            n++;
            if(val > m)
                m = val;
        }
    }
}

void ListaEncad::removeK(int k)
{
    if(k == 0)
        removeInicio();
    else
    {
        int i = 0;
        No *p = primeiro;
        No *ant = NULL;
        while(p != NULL && i < k)
        {
            ant = p;
            p = p->getProx();
            i++;
        }
        if(p == NULL)
            cout << "Indice invalido" << endl;
        else
        {
            ant->setProx(p->getProx());
            if(p == ultimo)
                ultimo = ant;
            int val = p->getInfo();
            delete p;
            n--;
            if(val == m)
                m = auxMaior();
        }
    }
}

void ListaEncad::insereApos(int x, int val)
{
    No *p = primeiro;
    while(p != NULL)
    {
        if(p->getInfo() == x)
            break;
        p = p->getProx();
    }
    if(p == NULL)
        cout << "No " << x << "nao existente" << endl;
    else
    {
        No *novo = new No();
        novo->setInfo(val);
        novo->setProx(p->getProx());
        p->setProx(novo);
        if(ultimo == p)
            ultimo = novo;
        n++;
        if(val > m)
            m = val;
    }
}

bool ListaEncad::busca(int val)
{
    No* p = primeiro;
    while(p != NULL)
    {
        if(p->getInfo() == val)
            return true;
        p = p->getProx();
    }
    return false;
}

void ListaEncad::imprime()
{
    for(No *p = primeiro; p != NULL; p = p->getProx())
        cout << p->getInfo() << " --> ";
    cout << "NULL -- ";
    cout << "Nos: " << numNos() << " -- ";
    cout << "Maior: " << maior() << endl;
}

int ListaEncad::numNos()
{
    return n;
}

int ListaEncad::auxMaior()
{
    No *m = primeiro;
    for(No *p = primeiro; p != NULL; p = p->getProx())
        if(p->getInfo() > m->getInfo())
            m = p;
    return m->getInfo();
}

int ListaEncad::maior()
{
    if(primeiro == NULL)
    {
        cout << "Lista vazia" << endl;
        exit(1);
    }
    /*
    No *m = primeiro;
    for(No *p = primeiro; p != NULL; p = p->getProx())
        if(p->getInfo() > m->getInfo())
            m = p;
    return m->getInfo();
    */
    return m;
}

ListaEncad* ListaEncad::partir(int val)
{
    ListaEncad *nova = new ListaEncad;

    No *p = primeiro;
    No *ant = NULL;
    int cont = 0;

    while(p != NULL)
    {
        if(p->getInfo() == val)
            break;
        ant = p;
        p = p->getProx();
        cont++;
    }
    if(p == NULL)
        cout << "No inexistente" << endl;
    else
    {
        if(ant == NULL) // p = primeiro
        {
            nova->primeiro = primeiro;
            nova->ultimo = ultimo;
            nova->n = n;
            nova->m = m;

            primeiro = ultimo = NULL;
            n = m = 0;
        }
        else
        {
            nova->primeiro = p;
            nova->ultimo = ultimo;
            nova->n = n-cont;

            ant->setProx(NULL);
            ultimo = ant;
            n = cont;

            nova->m = nova->auxMaior();
            m = auxMaior();
        }
    }
    return nova;
}







