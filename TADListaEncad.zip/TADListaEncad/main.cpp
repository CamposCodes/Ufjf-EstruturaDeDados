#include <iostream>
#include "ListaEncad.h"

using namespace std;

int main()
{
    ListaEncad l;

    l.insereK(1, 2);
    l.imprime();
    l.insereK(0, 2);
    l.imprime();
    l.insereInicio(5);
    l.imprime();
    l.insereInicio(4);
    l.imprime();
    l.insereInicio(3);
    l.imprime();
    l.insereInicio(2);
    l.imprime();
    l.insereInicio(1);
    l.imprime();
    l.insereK(2, 10);
    l.imprime();
    l.insereK(0, 11);
    l.imprime();

    l.removeK(1);
    l.imprime();
    l.removeK(0);
    l.imprime();


    ///
    /*
    l.insereFinal(1);
    l.insereFinal(2);
    l.insereFinal(3);
    l.insereFinal(4);
    l.insereFinal(5);
    l.imprime();
    l.removeFinal();
    l.imprime();
    l.removeFinal();
    l.imprime();
    l.removeFinal();
    l.imprime();
    l.removeFinal();
    l.imprime();
    l.removeFinal();
    l.imprime();
    l.removeFinal();
    l.imprime();
    */
    return 0;
};
