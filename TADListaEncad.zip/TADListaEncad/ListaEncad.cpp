#include <iostream>
#include <cstdlib>
#include "ListaEncad.h"

using namespace std;

ListaEncad::ListaEncad()
{
    primeiro = NULL;
}

ListaEncad::~ListaEncad()
{
    No *p = primeiro;
    while(p != NULL)
    {
        No *t = p->getProx();
        delete p;
        p = t;
    }
}

void ListaEncad::insereInicio(int val)
{
    No *p = new No(); // cria No apontado por p
    p->setInfo(val);
    p->setProx(primeiro);
    primeiro = p;
// preenche informacao
// preenche proximo
// no apontado por p passa
// a ser o primeiro da lista
}

void ListaEncad::removeInicio()
{
    if(primeiro != NULL)
    {
        No *p = primeiro;
        primeiro = p->getProx();
        delete p;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaEncad::insereFinal(int val)
{
    No *novo = new No(); // alocação
    novo->setInfo(val);  // ajuste novo info
    novo->setProx(NULL); // ajuste novo prox

    if(primeiro == NULL) // lista vazia
        primeiro = novo;
    else // descoberta do ultimo
    {
        No *ultimo = primeiro;
        while(ultimo->getProx() != NULL)
            ultimo = ultimo->getProx();
        ultimo->setProx(novo); //ajuste ultimo prox
    }
}

void ListaEncad::removeFinal()
{
    if(primeiro != NULL)
    {
        No *ultimo = primeiro;
        No *penultimo = NULL;
        while(ultimo->getProx() != NULL)
        {
            penultimo = ultimo;
            ultimo = ultimo->getProx();
        }
        if(penultimo == NULL)
            primeiro = NULL;
        else
            penultimo->setProx(NULL);
        delete ultimo;
    }
    else
        cout << "Lista vazia" << endl;
}

void ListaEncad::insereK(int k, int val)
{
    if(k == 0)
        insereInicio(val);
    else
    {
        int i = 0;
        No *p = primeiro;
        No *ant = NULL;
        while(p != NULL && i < k)
        {
            ant = p;
            p = p->getProx();
            i++;
        }
        if(p == NULL)
            cout << "Indice invalido" << endl;
        else
        {
            No *novo = new No();
            novo->setInfo(val);
            novo->setProx(p);
            ant->setProx(novo);
        }
    }
}

void ListaEncad::removeK(int k)
{
    if(k == 0)
        removeInicio();
    else
    {
        int i = 0;
        No *p = primeiro;
        No *ant = NULL;
        while(p != NULL && i < k)
        {
            ant = p;
            p = p->getProx();
            i++;
        }
        if(p == NULL)
            cout << "Indice invalido" << endl;
        else
        {
            ant->setProx(p->getProx());
            delete p;
        }
    }
}

bool ListaEncad::busca(int val)
{
    No* p = primeiro;
    while(p != NULL)
    {
        if(p->getInfo() == val)
            return true;
        p = p->getProx();
    }
    return false;
}

void ListaEncad::imprime()
{
    for(No *p = primeiro; p != NULL; p = p->getProx())
    {
        cout << p->getInfo() << " --> ";
    }
    cout << "NULL" << endl;
}

int ListaEncad::numNos()
{
    int cont = 0;
    for(No *p = primeiro; p != NULL; p = p->getProx())
        cont++;
    return cont;
}
