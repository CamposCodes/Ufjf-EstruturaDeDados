#include <iostream>
#include <cstdlib>
#include "MatrizDistancias.h"

using namespace std;

// ----------------------------------------------------------------------------
//Q4
MatrizDistancias::MatrizDistancias(int ordem)
{
    n = ordem;
    int tam = n*(n-1)/2;
    vet = new int[tam];
}

MatrizDistancias::~MatrizDistancias()
{
    delete [] vet;
}

int MatrizDistancias::detInd(int i, int j)
{
    if(i >= 0 && i < n && j >= 0 && j < n)
    {
        if(i > j)
            return i*(i-1)/2 + j;
        else
            return -2;
    }
    else
        return -1;
}

int MatrizDistancias::get(int i, int j)
{
    int k = detInd(i, j);
    if(k == -1)
    {
        cout << "indice invalido" << endl;
        exit(1);
    }
    else if(k == -2)
    {
        if(i == j)
            return 0;
        else
            return get(j, i);
    }
    else
        return vet[k];
}

void MatrizDistancias::set(int i, int j, int val)
{
    int k = detInd(i, j);
    if(k == -1)
        cout << "indice invalido" << endl;
    else if(k == -2)
    {
        if(i == j)
        {
            if(val != 0)
            cout << "valor invalido" << endl;
        }
        else
            set(j, i, val);
    }
    else
        vet[k] = val;
}
//-Q4
// ----------------------------------------------------------------------------

void MatrizDistancias::imprime()
{
    cout << "Matriz " << n << " x " << n << ":" << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            cout << get(i, j) << "\t";
        cout << endl;
    }
    cout << endl;
}
